# Edge Loop - Close the Feedback Cycle

Run the Edge Loop to close the feedback cycle:
- Generates proof visualization with CTI tracking
- Checks for CTI drift (warns if >5% drop)
- Archives daily report to `reports/`

## Usage

```bash
/edge-loop
```

## What It Does

1. Runs `tools/proof_visualizer.py --history`
2. Checks CTI drift via pure bash (no dependencies)
3. Archives `proof_viz.html` to `reports/proof_YYYY-MM-DD.html`

## When to Use

- End of work session (manual reflection)
- After completing an objective
- Anytime you want to see the current state

Note: This also runs automatically after `/edge-prune`.

## Instructions

Run the edge loop script:

```bash
bash tools/edge_loop.sh
```

Display the output to the user.
