# Installing Operator's Edge in Any Claude Code Project

## Quick Start (30 seconds)

```bash
# 1. Copy the operators-edge folder to your project
cp -r operators-edge /path/to/your/project/

# 2. Navigate to your project
cd /path/to/your/project/operators-edge

# 3. Run setup
python setup.py
```

That's it! Start Claude Code in your project and use `/edge`.

---

## What Gets Installed

```
your-project/
├── .claude/
│   ├── settings.json      # Hook configuration (created by setup.py)
│   ├── commands/          # Slash commands (/edge, /edge-plan, etc.)
│   └── hooks/             # Python enforcement hooks
├── CLAUDE.md              # Instructions Claude reads on startup
├── active_context.yaml    # Your plan and state (created on first use)
└── templates/             # Starter templates
```

---

## Installation Options

### Option A: Copy Entire Folder (Recommended)

Best for: New projects or when you want full control

```bash
# Copy to your project root
cp -r operators-edge/* /path/to/your/project/

# Run setup
cd /path/to/your/project
python setup.py
```

### Option B: Git Submodule

Best for: Keeping Edge updated across multiple projects

```bash
cd /path/to/your/project
git submodule add https://github.com/DazedtilDawn/operators-edge.git .operators-edge

# Symlink or copy what you need
cp -r .operators-edge/.claude .claude
cp .operators-edge/CLAUDE.md CLAUDE.md
python .operators-edge/setup.py
```

### Option C: NPX-style (Future)

Coming soon: `npx operators-edge init`

---

## Platform Notes

### Windows
- Uses `python` command
- Paths use backslashes internally but setup.py handles this

### Mac/Linux
- Uses `python3` command
- Standard Unix paths

The setup.py auto-detects your platform and configures hooks correctly.

---

## Verify Installation

```bash
# Run the validation test
python validate_v6.py
```

Expected: `ALL 30 TESTS PASSED ✓`

---

## Using Operator's Edge

Once installed, start Claude Code and use:

```bash
# The "just works" way (v6.0+)
/edge "Build a login system"

# Classic commands
/edge-plan          # Create a plan
/edge-step          # Execute current step
/edge-yolo on       # Enable autopilot
/edge               # Smart orchestrator
```

---

## Updating

To update an existing installation:

```bash
# Pull latest (if using git)
git pull origin main

# Or re-copy from new version
cp -r new-operators-edge/.claude/* your-project/.claude/
cp new-operators-edge/CLAUDE.md your-project/

# Re-run setup to update settings.json
python setup.py
```

---

## Uninstalling

```bash
# Remove Edge files
rm -rf .claude/hooks .claude/commands
rm CLAUDE.md active_context.yaml
rm -rf .proof

# Keep .claude/settings.json if you have other customizations
# Or remove it too: rm .claude/settings.json
```

---

## Troubleshooting

### "Python not found"
- Windows: Install Python from python.org, ensure "Add to PATH" is checked
- Mac: `brew install python3` or use system Python

### "Hook not firing"
- Check `.claude/settings.json` exists and has hooks configured
- Run `python setup.py` again

### "Permission denied"
- Mac/Linux: `chmod +x .claude/hooks/*.py`

### "Module not found"
- All hooks are self-contained, no pip install needed
- Check that `.claude/hooks/` contains all .py files

---

## Support

- GitHub: https://github.com/DazedtilDawn/operators-edge
- Issues: https://github.com/DazedtilDawn/operators-edge/issues
